using Microsoft.EntityFrameworkCore;
using LostAndFound.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Register ApplicationDbContext
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Item}/{action=Index}/{id?}");

using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<LostAndFound.Data.ApplicationDbContext>();
    if (!context.Categories.Any())
    {
        context.Categories.AddRange(
            new LostAndFound.Models.Category { Name = "�ػ�ó�����硷�͹ԡ��" },
            new LostAndFound.Models.Category { Name = "�͡��� / ������ʵҧ��" },
            new LostAndFound.Models.Category { Name = "����ͼ�� / ����ͧ�觡��" },
            new LostAndFound.Models.Category { Name = "�ح�" },
            new LostAndFound.Models.Category { Name = "����" }
        );
        context.SaveChanges();
    }
}

app.Run();